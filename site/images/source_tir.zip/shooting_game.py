import sys
import pygame
import pygame.image
import pygame.rect
import pygame.event
import pygame.key
import pygame.math
import pygame.time
import pygame.mouse
import pygame.display
import pygame.sprite
from crosshair import CrossShooter, Target

def target_spawning(n_targets: int, dest_group: pygame.sprite.Group):
    for _ in range(n_targets):
        dest_group.add(Target(SCREEN_WIDTH, SCREEN_HEIGHT))

pygame.init()
pygame.mouse.set_visible(False)
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 500
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
player_crosshair = CrossShooter()
cross_group = pygame.sprite.GroupSingle(player_crosshair)
running = True
clock = pygame.time.Clock()
target_group = pygame.sprite.Group()
target_spawning(20, target_group)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            player_crosshair.shoot()
    screen.fill((200, 200, 255))
    target_group.draw(screen)
    target_group.update()
    cross_group.draw(screen)
    cross_group.update(target_group)
    pygame.display.update()
    clock.tick(60)
