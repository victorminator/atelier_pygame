from email.mime import image
import random
import pygame
import pygame.image
import pygame.rect
import pygame.event
import pygame.key
import pygame.math
import pygame.time
import pygame.mouse
import pygame.display
import pygame.sprite
import pygame.transform
import pygame.mixer

def rand_on_condition(a, b, n_min=None, n_max=None):
    generation = random.randint(a, b)
    if n_min != None and abs(generation) < n_min:
        return 0
    if n_max != None and abs(generation) > n_max:
        return 0
    return generation

class Target(pygame.sprite.Sprite):
    def __init__(self, lim_x, lim_y):
        super().__init__()
        self.boundaries = {"x":lim_x, "y":lim_y}
        self.image = pygame.image.load("images/target.png").convert_alpha()
        rand_posx = random.randint(0, lim_x - self.image.get_width())
        rand_posy = random.randint(0, lim_y - self.image.get_height())
        self.rect = self.image.get_rect(topleft=(rand_posx, rand_posy))
        rand_dirx = rand_on_condition(-10, 10, n_min=3, n_max=8)
        rand_diry = 0 if rand_dirx > 5 else rand_on_condition(-10, 10, n_min=3, n_max=8)
        self.vector = pygame.math.Vector2(rand_dirx, rand_diry)
    
    def bounce_effect(self):
        if self.rect.top < 0:
            self.rect.top = 0
            self.vector.y *= -1
        elif self.rect.bottom > self.boundaries["y"]:
            self.rect.bottom = self.boundaries["y"]
            self.vector.y *= -1
        if self.rect.left < 0:
            self.rect.left = 0
            self.vector.x *= -1
        elif self.rect.right > self.boundaries["x"]:
            self.rect.right = self.boundaries["x"]
            self.vector.x *= -1
        
    def update(self):
        self.rect.topleft += self.vector
        self.bounce_effect()

class CrossShooter(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("images/crossaim_31.png").convert_alpha()
        self.rect = self.image.get_rect(center=pygame.mouse.get_pos())
        self.target_collisions = []
    
    def target_detection(self, targeted_group: pygame.sprite.Group):
        self.target_collisions = pygame.sprite.spritecollide(self, targeted_group, dokill=False)
        if self.target_collisions:
            self.image = pygame.image.load("images/crossaim_30.png").convert_alpha()
        else:
            self.image = pygame.image.load("images/crossaim_31.png").convert_alpha()
    
    def shoot(self):
        self.image = pygame.image.load("images/crossaim_29.png").convert_alpha() 
        pygame.mixer.Sound("images/8bit_gunloop_explosion.wav").play()
        for target_sprite in self.target_collisions:
            target_sprite.kill()

    
    def update(self, targeted_group):
        self.rect.center = pygame.mouse.get_pos()
        self.target_detection(targeted_group)
